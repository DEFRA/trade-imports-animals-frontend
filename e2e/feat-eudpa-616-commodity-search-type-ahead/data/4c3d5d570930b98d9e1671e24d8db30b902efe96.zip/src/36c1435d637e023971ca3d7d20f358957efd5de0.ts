import { pageLoadWait } from '@config/timeouts';
import { fileUploadTimeouts } from '@config/file-upload-timeouts';
import { type Locator } from '@playwright/test';
import type { AnimalsPages, SharedPages } from '@page-objects';
import type { SaveAndContinueStop } from '@page-objects/shared/journey-checks';
import type { InsAddressBookAddPage } from '@page-objects/ins/address-book/add-page';
import type { InsNotificationTypePage } from '@page-objects/ins/notification-type-page';
import { LIVE_ANIMALS, type NotificationTypeOption } from '@domain/ins/constants/notification-types';
import type { PartyRole } from '@page-objects/animals/addresses-page';
import type { AnimalsPartyPickerPage } from '@page-objects/animals/party-picker-page';
import type { CommercialTransporterDetails } from '@page-objects/animals/commercial-transporter-page';
import type { PrivateTransporterDetails } from '@page-objects/animals/private-transporter-page';
import {
  ALL_ANSWERS,
  MANDATORY_ANSWERS,
  assertConsistentAnswers,
  type AccompanyingDocumentAnswer,
  type CphAnswer,
  type NotificationAnswers,
  type OriginOptions,
  type PartyAnswers,
} from '@domain/animals/constants/journey-options';
import { type CommodityLineAnswer } from '@domain/animals/constants/journey-commodity-line-answers';
import { certificationPurposes } from '@domain/animals/constants/certification-purposes';
import { internalMarketPurposes } from '@domain/animals/constants/internal-market-purposes';
import { IMPORT_REASON_TASK } from '@domain/animals/constants/import-reason-page';
import { meansOfTransport } from '@domain/animals/constants/means-of-transport';
import { DEFAULT_REGION_CODE } from '@domain/animals/constants/origin-page';
import { pointOfEntries } from '@domain/animals/constants/point-of-entries';
import { fileUploadPaths } from '@resources/file-upload/paths';
import { getRelativeAppDateText } from '@utils/date-utils';
import type { JourneyContext } from '@flows/shared/journey-context';
import { countryCodes } from '@domain/animals/constants/country-codes';
import { commodityLines, type CommodityLine } from '@domain/animals/constants/commodity-lines';
import { importReasons } from '@domain/animals/constants/import-reasons';
import { yesNoValues } from '@domain/shared/constants/yes-no-values';

export type ArrivalDetailsAnswer = {
  date?: string;
  means?: string;
  port?: string;
  transportId?: string;
  documentReference?: string;
};

type PartyPickerKey = 'consignorSelection' | 'destinationSelection' | 'placeOfOriginSelection' | 'consigneeSelection' | 'importerSelection';

type PartyAnswer = [role: PartyRole, name: string];

const PARTY_PICKER_KEYS: Record<PartyRole, PartyPickerKey> = {
  Consignor: 'consignorSelection',
  'Place of destination': 'destinationSelection',
  'Place of origin': 'placeOfOriginSelection',
  Consignee: 'consigneeSelection',
  Importer: 'importerSelection',
};

type AnimalWithPermanentAddress = Required<Pick<CommodityLineAnswer, 'passportNumber' | 'permanentAddress'>>;

export type SpeciesAnimalCount = {
  species: CommodityLine;
  animalCount: number;
};

export const AIR_OR_SEA_OVERVIEW_TASKS = [
  'Where is this consignment coming from?',
  'What are you importing?',
  IMPORT_REASON_TASK,
  'Commodity details',
  'Identification details',
  'Additional details',
  'Arrival details',
  'Transport details',
  'Upload documents',
  'Roles and addresses',
  'Contact address for this consignment',
] as const;

export const OVERLAND_WITHOUT_IDENTIFICATION_OVERVIEW_TASKS = [
  'Where is this consignment coming from?',
  'What are you importing?',
  IMPORT_REASON_TASK,
  'Commodity details',
  'Additional details',
  'Arrival details',
  'Transit countries',
  'Transport details',
  'Upload documents',
  'Roles and addresses',
  'Contact address for this consignment',
] as const;

export const TEMPORARY_ADMISSION_EXIT_DATE = getRelativeAppDateText({ monthOffset: 2 });

export const HORSE_TRANSPORT_ID = 'STENA ADVENTURER';
export const HORSE_TRANSPORTER = 'J & G Campbell LTD';

const timestampedReference = (referencePrefix: string): string => `${referencePrefix}${Date.now()}`;

export const certificateDocument = (referencePrefix: string): AccompanyingDocumentAnswer => ({
  reference: timestampedReference(referencePrefix),
  issueDate: '03/01/2026',
  filePath: fileUploadPaths.safeFile1kbPdf,
  type: 'VETERINARY_HEALTH_CERTIFICATE',
});

export class AnimalsJourney {
  constructor(
    private readonly animalsPages: AnimalsPages,
    private readonly pages: SharedPages,
    private readonly context: JourneyContext,
  ) {}

  /** The pages Save and continue goes through from the main import reason to the contact address, in order, starting at `first`. */
  saveAndContinueStopsFrom(first: SaveAndContinueStop): SaveAndContinueStop[] {
    const stops: SaveAndContinueStop[] = [
      this.animalsPages.importReason,
      this.animalsPages.consignmentDetails,
      this.animalsPages.animalIdentification,
      this.animalsPages.additionalDetails,
      this.animalsPages.arrivalDetails,
      this.animalsPages.transitedCountries,
      this.animalsPages.transporter,
      this.animalsPages.accompanyingDocuments,
      this.animalsPages.addresses,
      this.animalsPages.contactAddress,
    ];
    return stops.slice(stops.indexOf(first));
  }

  async toSignIn(open: (attemptSignIn: boolean) => Promise<void>): Promise<void> {
    await open(false);
  }

  async toNotificationDashboard(): Promise<void> {
    await this.animalsPages.dashboard.open();
    await this.animalsPages.dashboard.heading.waitFor(pageLoadWait);
  }

  async createNotificationAtOrigin(): Promise<string> {
    await this.toNotificationDashboard();
    await this.animalsPages.dashboard.btnCreateNewNotification.click();
    await this.animalsPages.originOfImport.heading.waitFor(pageLoadWait);
    return this.recordReferenceNumberFromUrl();
  }

  private recordReferenceNumberFromUrl(): string {
    const referenceNumber = this.animalsPages.originOfImport.referenceNumberFromUrl();
    this.context.recordReferenceNumber(referenceNumber);
    return referenceNumber;
  }

  async saveOrigin(): Promise<string> {
    const referenceNumber = await this.createNotificationAtOrigin();
    await this.fillOriginOfImport();
    await this.saveOriginOfImport();
    await this.animalsPages.commoditySelection.heading.waitFor();
    return referenceNumber;
  }

  async startNotification(): Promise<string> {
    const referenceNumber = await this.createNotificationAtOrigin();
    await this.fillOriginOfImport();
    await this.saveOriginOfImport();
    await this.animalsPages.originOfImport.heading.waitFor({ ...pageLoadWait, state: 'hidden' });
    await this.animalsPages.overview.open(referenceNumber);
    await this.animalsPages.overview.heading.waitFor(pageLoadWait);
    return referenceNumber;
  }

  async startNotificationFromInsTypeQuestion(notificationTypePage: InsNotificationTypePage, type: NotificationTypeOption): Promise<string> {
    await notificationTypePage.open();
    await notificationTypePage.chooseNotificationType(type);
    await this.animalsPages.originOfImport.heading.waitFor(pageLoadWait);
    return this.recordReferenceNumberFromUrl();
  }

  async backToInsTypeQuestion(): Promise<void> {
    await this.animalsPages.originOfImport.followBackToInsTypeQuestion();
  }

  /** Starts a live animals draft from the INS question, follows origin's Back link to the question and returns the draft's reference. */
  async toInsTypeQuestionFromNewLiveAnimalsOrigin(notificationTypePage: InsNotificationTypePage): Promise<string> {
    const reference = await this.startNotificationFromInsTypeQuestion(notificationTypePage, LIVE_ANIMALS);
    await this.backToInsTypeQuestion();
    return reference;
  }

  async backToInsTypeQuestionAndChoose(notificationTypePage: InsNotificationTypePage, type: NotificationTypeOption): Promise<void> {
    await this.backToInsTypeQuestion();
    await notificationTypePage.chooseNotificationType(type);
  }

  async answerOriginAndSelectSpecies(speciesList: CommodityLine[], options: OriginOptions = {}): Promise<void> {
    await this.fillOriginOfImport(options);
    await this.saveOriginOfImport();
    await this.animalsPages.commoditySelection.heading.waitFor(pageLoadWait);
    await this.checkSpeciesAndSave(speciesList);
    await this.animalsPages.commoditySelection.heading.waitFor({ ...pageLoadWait, state: 'hidden' });
  }

  async toOriginOfImport(): Promise<void> {
    await this.createNotificationAtOrigin();
  }

  async fillOriginOfImport(options: OriginOptions = {}): Promise<void> {
    await this.animalsPages.originOfImport.country.choose((options.countryCode ?? MANDATORY_ANSWERS.countryCode).display);
    const requiresRegionCode = options.requiresRegionCode ?? MANDATORY_ANSWERS.requiresRegionCode;
    await this.animalsPages.originOfImport.radioRequiresOriginCode(requiresRegionCode).check();
    if (requiresRegionCode === 'Yes') {
      await this.animalsPages.originOfImport.regionCode.fill(options.regionCode ?? DEFAULT_REGION_CODE);
    }
    if (options.internalReference) {
      await this.animalsPages.originOfImport.internalReference.fill(options.internalReference);
    }
  }

  async saveOriginOfImport(): Promise<void> {
    await this.animalsPages.originOfImport.saveAndContinue.click();
  }

  async fillAndSaveOriginWithRegionCode(regionCode: string, options: OriginOptions = {}): Promise<void> {
    await this.fillOriginOfImport({ ...options, requiresRegionCode: 'Yes', regionCode });
    await this.saveOriginOfImport();
  }

  async openOriginFromOverview(): Promise<void> {
    await this.animalsPages.overview.task('Where is this consignment coming from?').click();
    await this.animalsPages.originOfImport.heading.waitFor(pageLoadWait);
  }

  async toOriginFromOverview(): Promise<void> {
    await this.startNotification();
    await this.openOriginFromOverview();
  }

  async answerOrigin(answers: NotificationAnswers = MANDATORY_ANSWERS): Promise<void> {
    await this.openOriginFromOverview();
    await this.fillOriginOfImport(answers);
    await this.saveOriginOfImport();
    await this.animalsPages.commoditySelection.heading.waitFor(pageLoadWait);
    await this.openCurrentOverview();
  }

  private async checkSpeciesAndSave(
    speciesList: CommodityLine[],
    saveControl: Locator = this.animalsPages.commoditySelection.saveAndContinue,
  ): Promise<void> {
    await this.animalsPages.commoditySelection.searchAndCheckSpecies(speciesList);
    await saveControl.click();
  }

  private async chooseSpeciesAndOpenDetails(speciesList: CommodityLine[]): Promise<void> {
    await this.checkSpeciesAndSave(speciesList, this.animalsPages.commoditySelection.saveAndReturnToOverview);
    await this.animalsPages.overview.heading.waitFor(pageLoadWait);
    await this.openCommodityDetailsFromOverview();
  }

  private async openCommodityDetailsFromOverview(): Promise<void> {
    await this.animalsPages.overview.task('Commodity details').click();
    await this.animalsPages.consignmentDetails.heading.waitFor(pageLoadWait);
  }

  private async openIdentificationFromOverview(): Promise<void> {
    await this.animalsPages.overview.task('Identification details').click();
    await this.animalsPages.animalIdentification.heading.waitFor(pageLoadWait);
  }

  private async saveCountsAndReturnToOverview(): Promise<void> {
    await this.animalsPages.consignmentDetails.saveAndReturnToOverview.click();
    await this.animalsPages.overview.heading.waitFor(pageLoadWait);
  }

  async openReviewFromOverview(): Promise<void> {
    await this.animalsPages.overview.reviewAndSubmitButton.click();
    await this.animalsPages.notificationView.heading.waitFor(pageLoadWait);
  }

  private async chooseSpeciesAndSaveAnimalCountsToOverview(speciesCounts: SpeciesAnimalCount[]): Promise<void> {
    await this.toConsignmentDetails(speciesCounts.map(({ species }) => species));
    for (const { species, animalCount } of speciesCounts) {
      await this.animalsPages.consignmentDetails.fillAnimalCountFor(species, animalCount);
    }
    await this.saveCountsAndReturnToOverview();
  }

  private currentReferenceNumber(): string {
    const { referenceNumber } = this.context;
    if (!referenceNumber) throw new Error('No notification has been started');
    return referenceNumber;
  }

  async openCurrentOverview(): Promise<void> {
    await this.animalsPages.overview.open(this.currentReferenceNumber());
    await this.animalsPages.overview.heading.waitFor(pageLoadWait);
  }

  private async openAdditionalDetailsFromOverview(): Promise<void> {
    await this.animalsPages.overview.task('Additional details').click();
    await this.animalsPages.additionalDetails.heading.waitFor(pageLoadWait);
  }

  async answerCommodity(answers: NotificationAnswers = MANDATORY_ANSWERS): Promise<void> {
    const { commodityLines: lines } = answers;
    await this.animalsPages.overview.task('What are you importing?').click();
    await this.chooseSpeciesAndOpenDetails(lines.map((line) => line.species));
    for (const line of lines) {
      await this.animalsPages.consignmentDetails.fillAnimalCountFor(line.species, line.noOfAnimals);
      if (line.noOfPackages !== undefined) {
        await this.animalsPages.consignmentDetails.fillPackageCountFor(line.species, line.noOfPackages);
      }
    }
    await this.animalsPages.consignmentDetails.saveAndReturnToOverview.click();
    await this.animalsPages.overview.heading.waitFor(pageLoadWait);
  }

  async answerAnimalIdentification(answers: NotificationAnswers = MANDATORY_ANSWERS): Promise<void> {
    const { commodityLines: lines } = answers;
    await this.animalsPages.overview.task('Identification details').click();
    const { animalIdentification: identification } = this.animalsPages;
    for (const line of lines) {
      const card = identification.speciesCard(line.species);
      if (line.earTag) {
        await card.getByLabel('Ear tag', { exact: true }).fill(line.earTag);
      }
      if (line.passportNumber) {
        await card.getByLabel('Passport', { exact: true }).fill(line.passportNumber);
      }
      if (line.microchip) {
        await card.getByLabel('Microchip', { exact: true }).fill(line.microchip);
      }
      if (line.tattoo) {
        await card.getByLabel('Tattoo', { exact: true }).fill(line.tattoo);
      }
      if (line.permanentAddress) {
        await identification.fillPermanentAddress(line.permanentAddress, card);
      }
    }
    await identification.saveAndReturnToOverview.click();
    await this.animalsPages.overview.heading.waitFor(pageLoadWait);
  }

  async answerReasonAndAdditionalDetails(answers: NotificationAnswers = MANDATORY_ANSWERS): Promise<void> {
    await this.animalsPages.overview.task(IMPORT_REASON_TASK).click();
    await this.animalsPages.importReason.reason(answers.importReason.display).check();
    await this.animalsPages.importReason.purpose(answers.internalMarketPurpose.display).check();
    await this.animalsPages.importReason.saveAndReturnToOverview.click();
    await this.animalsPages.overview.heading.waitFor(pageLoadWait);
    await this.openAdditionalDetailsFromOverview();
    await this.animalsPages.additionalDetails.certifiedFor(answers.certifiedFor.display).check();
    await this.animalsPages.additionalDetails.containsUnweanedAnimals(answers.unweanedAnimals).check();
    await this.animalsPages.additionalDetails.saveAndReturnToOverview.click();
    await this.animalsPages.overview.heading.waitFor(pageLoadWait);
  }

  async toAccompanyingDocuments(): Promise<void> {
    await this.startNotification();
    await this.answerCommodity();
    await this.animalsPages.overview.task('Upload documents').click();
    await this.animalsPages.accompanyingDocuments.heading.waitFor(pageLoadWait);
  }

  async addFiveParties(names: PartyAnswers = MANDATORY_ANSWERS.parties): Promise<void> {
    await this.addParties([['Consignor', names.consignor]]);
    await this.addRemainingParties(names);
  }

  async addRemainingParties(names: PartyAnswers = MANDATORY_ANSWERS.parties): Promise<void> {
    await this.addParties([
      ['Place of destination', names.placeOfDestination],
      ['Place of origin', names.placeOfOrigin],
      ['Consignee', names.consignee],
      ['Importer', names.importer],
    ]);
  }

  private async addParties(parties: PartyAnswer[]): Promise<void> {
    for (const [role, name] of parties) {
      const picker = this.partyPicker(role);
      await this.animalsPages.addresses.addParty(role).click();
      await picker.select(name);
      await picker.saveAndContinue.click();
      await this.animalsPages.addresses.heading.waitFor(pageLoadWait);
    }
  }

  async fillAddressesAndOpenCph(): Promise<void> {
    await this.animalsPages.overview.task('Roles and addresses').click();
    await this.addFiveParties();
    await this.animalsPages.addresses.addCph.click();
    await this.animalsPages.cphNumber.heading.waitFor(pageLoadWait);
  }

  async addCphAndLeaveAddresses(cph: CphAnswer = MANDATORY_ANSWERS.cph): Promise<void> {
    await this.animalsPages.addresses.addCph.click();
    await this.animalsPages.cphNumber.heading.waitFor(pageLoadWait);
    await this.animalsPages.cphNumber.fillCphNumber(cph);
    await this.animalsPages.cphNumber.saveAndContinue.click();
    await this.animalsPages.addresses.heading.waitFor(pageLoadWait);
    await this.animalsPages.addresses.continueButton.click();
    await this.animalsPages.contactAddress.heading.waitFor(pageLoadWait);
  }

  async answerAddresses(answers: NotificationAnswers = MANDATORY_ANSWERS): Promise<void> {
    await this.animalsPages.overview.task('Roles and addresses').click();
    await this.addFiveParties(answers.parties);
    await this.addCphAndLeaveAddresses(answers.cph);
    await this.animalsPages.contactAddress.saveAndReturnToOverview.click();
    await this.animalsPages.overview.heading.waitFor(pageLoadWait);
  }

  async fillArrivalDetails({
    date = MANDATORY_ANSWERS.arrivalDate,
    means = MANDATORY_ANSWERS.meansOfTransport.display,
    port = MANDATORY_ANSWERS.pointOfEntry.display,
    transportId = MANDATORY_ANSWERS.transportIdentification,
    documentReference = MANDATORY_ANSWERS.transportDocumentReference,
  }: ArrivalDetailsAnswer = {}): Promise<void> {
    await this.animalsPages.arrivalDetails.fillArrivalDate(date);
    await this.animalsPages.arrivalDetails.portOfEntry.choose(port);
    await this.animalsPages.arrivalDetails.chooseMeansOfTransport(means);
    await this.animalsPages.arrivalDetails.transportIdentification.fill(transportId);
    await this.animalsPages.arrivalDetails.transportDocumentReference.fill(documentReference);
  }

  async uploadDocumentAndWaitForScan(document: AccompanyingDocumentAnswer): Promise<void> {
    await this.animalsPages.accompanyingDocuments.fillDocument(document.reference, document.issueDate, document.filePath, document.type);
    await this.animalsPages.accompanyingDocuments.saveAndAddAnother.click();
    await this.waitForDocumentScanComplete(document.reference);
  }

  async waitForDocumentScanComplete(reference: string): Promise<void> {
    await this.animalsPages.accompanyingDocuments
      .documentRow(reference)
      .filter({ hasText: 'Check completed' })
      .waitFor({ state: 'visible', timeout: fileUploadTimeouts.virusScanComplete });
  }

  async uploadScannedDocument(): Promise<Locator> {
    const reference = timestampedReference('PW');
    await this.uploadDocumentAndWaitForScan({ ...ALL_ANSWERS.accompanyingDocument, reference });
    return this.animalsPages.accompanyingDocuments.documentRow(reference);
  }

  async chooseContactAddress(name: string = MANDATORY_ANSWERS.contactAddress): Promise<void> {
    await this.animalsPages.contactAddress.address(name).check();
    await this.animalsPages.contactAddress.saveAndContinue.click();
  }

  private async saveContactAddressToOverview(name: string): Promise<void> {
    await this.animalsPages.contactAddress.address(name).check();
    await this.animalsPages.contactAddress.saveAndReturnToOverview.click();
  }

  async reachTransporterFromHub(): Promise<void> {
    await this.saveArrivalDetailsFromOverview();
    await this.animalsPages.overview.task('Transit countries').click();
    await this.animalsPages.transitedCountries.heading.waitFor(pageLoadWait);
    await this.animalsPages.transitedCountries.addCountry(ALL_ANSWERS.transitedCountries[0].display);
    await this.animalsPages.transitedCountries.saveAndReturnToOverview.click();
    await this.openTransporterFromOverview();
  }

  async openTransporterFromOverview(): Promise<void> {
    await this.animalsPages.overview.heading.waitFor(pageLoadWait);
    await this.animalsPages.overview.task('Transport details').click();
    await this.animalsPages.transporter.heading.waitFor(pageLoadWait);
  }

  async saveTransporterDetailsToOverview(form: { saveAndContinue: Locator }): Promise<void> {
    await form.saveAndContinue.click();
    await this.animalsPages.transporter.heading.waitFor(pageLoadWait);
    await this.animalsPages.transporter.saveAndReturnToOverview.click();
    await this.animalsPages.overview.heading.waitFor(pageLoadWait);
  }

  async chooseTransporterType(type: 'Commercial' | 'Private'): Promise<void> {
    await this.animalsPages.transporter.addTransporter.click();
    await this.animalsPages.transporterAdd.heading.waitFor(pageLoadWait);
    await this.animalsPages.transporterAdd.transporterType(type).check();
    await this.animalsPages.transporterAdd.continueButton.click();
  }

  async answerTransport(answers: NotificationAnswers = MANDATORY_ANSWERS): Promise<void> {
    await this.animalsPages.overview.task('Arrival details').click();
    await this.saveArrivalDetailsOnOpenPage({
      date: answers.arrivalDate,
      means: answers.meansOfTransport.display,
      port: answers.pointOfEntry.display,
      transportId: answers.transportIdentification,
      documentReference: answers.transportDocumentReference,
    });
    if (answers.transitedCountries) {
      await this.animalsPages.overview.task('Transit countries').click();
      await this.animalsPages.transitedCountries.heading.waitFor(pageLoadWait);
      for (const country of answers.transitedCountries) {
        await this.animalsPages.transitedCountries.addCountry(country.display);
      }
      await this.animalsPages.transitedCountries.saveAndReturnToOverview.click();
      await this.animalsPages.overview.heading.waitFor(pageLoadWait);
    }
    await this.animalsPages.overview.task('Transport details').click();
    await this.animalsPages.transporter.heading.waitFor(pageLoadWait);
    await this.animalsPages.transporter.transporter(answers.transporter.display).check();
    await this.animalsPages.transporter.saveAndReturnToOverview.click();
    await this.animalsPages.overview.heading.waitFor(pageLoadWait);
  }

  async answerContact(answers: NotificationAnswers = MANDATORY_ANSWERS): Promise<void> {
    await this.animalsPages.overview.task('Contact address for this consignment').click();
    await this.saveContactAddressToOverview(answers.contactAddress);
    await this.animalsPages.overview.heading.waitFor(pageLoadWait);
  }

  async answerAccompanyingDocument(answers: NotificationAnswers = MANDATORY_ANSWERS): Promise<void> {
    if (!answers.accompanyingDocument) return;
    await this.animalsPages.overview.task('Upload documents').click();
    await this.animalsPages.accompanyingDocuments.heading.waitFor(pageLoadWait);
    await this.uploadDocumentAndWaitForScan(answers.accompanyingDocument);
    await this.openCurrentOverview();
  }

  async completeAnswerSections(answers: NotificationAnswers = MANDATORY_ANSWERS): Promise<void> {
    assertConsistentAnswers(answers);
    await this.answerOrigin(answers);
    await this.answerCommodity(answers);
    await this.answerAnimalIdentification(answers);
    await this.answerReasonAndAdditionalDetails(answers);
    await this.answerAddresses(answers);
    await this.answerTransport(answers);
    await this.answerContact(answers);
    await this.answerAccompanyingDocument(answers);
  }

  async toCommoditySelection(): Promise<void> {
    await this.startNotification();
    await this.animalsPages.overview.task('What are you importing?').click();
    await this.animalsPages.commoditySelection.heading.waitFor(pageLoadWait);
  }

  async toConsignmentDetails(speciesList: CommodityLine[] = [MANDATORY_ANSWERS.commodityLines[0].species]): Promise<void> {
    await this.toCommoditySelection();
    await this.chooseSpeciesAndOpenDetails(speciesList);
  }

  async toOverviewWithSavedCounts(counts: { animals: string; packages: string }): Promise<void> {
    await this.toConsignmentDetails();
    await this.animalsPages.consignmentDetails.numberOfAnimals.fill(counts.animals);
    await this.animalsPages.consignmentDetails.numberOfPackages.fill(counts.packages);
    await this.saveCountsAndReturnToOverview();
  }

  async toConsignmentDetailsWithSavedCounts(counts: { animals: string; packages: string }): Promise<void> {
    await this.toOverviewWithSavedCounts(counts);
    await this.openCommodityDetailsFromOverview();
  }

  async addCommodityToCurrentNotificationAndFillEveryAnimalCountToOne(line: CommodityLine): Promise<void> {
    await this.openCurrentOverview();
    await this.animalsPages.overview.task('What are you importing?').click();
    await this.chooseSpeciesAndOpenDetails([line]);
    await this.animalsPages.consignmentDetails.fillEveryAnimalCount('1');
    await this.saveCountsAndReturnToOverview();
  }

  async toAnimalIdentification(): Promise<void> {
    await this.startNotification();
    await this.answerCommodity();
    await this.openIdentificationFromOverview();
  }

  async toAnimalIdentificationWithCounts(speciesCounts: SpeciesAnimalCount[]): Promise<void> {
    await this.chooseSpeciesAndSaveAnimalCountsToOverview(speciesCounts);
    await this.openIdentificationFromOverview();
  }

  async toReviewWithAnimalCounts(speciesCounts: SpeciesAnimalCount[]): Promise<void> {
    await this.chooseSpeciesAndSaveAnimalCountsToOverview(speciesCounts);
    await this.openReviewFromOverview();
  }

  async saveAnimalWithPermanentAddress({ passportNumber, permanentAddress }: AnimalWithPermanentAddress): Promise<void> {
    const identification = this.animalsPages.animalIdentification;
    await identification.passportNumber.fill(passportNumber);
    await identification.fillPermanentAddress(permanentAddress);
    await identification.saveAndAddAnother.click();
  }

  async toImportReason(): Promise<void> {
    await this.startNotification();
    await this.answerCommodity();
    await this.animalsPages.overview.task(IMPORT_REASON_TASK).click();
    await this.animalsPages.importReason.heading.waitFor(pageLoadWait);
  }

  async toAdditionalDetails(): Promise<void> {
    await this.toImportReason();
    await this.animalsPages.importReason.reason(importReasons.internalMarket.display).check();
    await this.animalsPages.importReason.purpose(internalMarketPurposes.breeding.display).check();
    await this.animalsPages.importReason.saveAndReturnToOverview.click();
    await this.animalsPages.overview.heading.waitFor(pageLoadWait);
    await this.openAdditionalDetailsFromOverview();
  }

  async toAdditionalDetailsOfCurrentNotification(): Promise<void> {
    await this.openCurrentOverview();
    await this.openAdditionalDetailsFromOverview();
  }

  async toRolesAndAddressesOfCurrentNotification(): Promise<void> {
    await this.openCurrentOverview();
    await this.animalsPages.overview.task('Roles and addresses').click();
    await this.animalsPages.addresses.heading.waitFor(pageLoadWait);
  }

  async toCphNumber(): Promise<void> {
    await this.startNotification();
    await this.answerCommodity();
    await this.fillAddressesAndOpenCph();
  }

  async toArrivalDetails(): Promise<void> {
    await this.startNotification();
    await this.answerCommodity();
    await this.animalsPages.overview.task('Arrival details').click();
    await this.animalsPages.arrivalDetails.heading.waitFor(pageLoadWait);
  }

  async saveArrivalDetailsFromOverview(means: string = MANDATORY_ANSWERS.meansOfTransport.display): Promise<void> {
    await this.animalsPages.overview.task('Arrival details').click();
    await this.saveArrivalDetailsOnOpenPage({ means });
  }

  async saveArrivalDetailsOnOpenPage(answer: ArrivalDetailsAnswer): Promise<void> {
    await this.animalsPages.arrivalDetails.heading.waitFor(pageLoadWait);
    await this.fillArrivalDetails(answer);
    await this.animalsPages.arrivalDetails.saveAndReturnToOverview.click();
    await this.animalsPages.overview.heading.waitFor(pageLoadWait);
  }

  async toTransitedCountries(): Promise<void> {
    await this.startNotification();
    await this.answerCommodity();
    await this.saveArrivalDetailsFromOverview();
    await this.animalsPages.overview.task('Transit countries').click();
    await this.animalsPages.transitedCountries.heading.waitFor(pageLoadWait);
  }

  async toTransporter(): Promise<void> {
    await this.toTransitedCountries();
    await this.animalsPages.transitedCountries.addCountry(ALL_ANSWERS.transitedCountries[0].display);
    await this.animalsPages.transitedCountries.saveAndReturnToOverview.click();
    await this.animalsPages.overview.heading.waitFor(pageLoadWait);
    await this.animalsPages.overview.task('Transport details').click();
    await this.animalsPages.transporter.heading.waitFor(pageLoadWait);
  }

  async toCommercialTransporter(): Promise<void> {
    await this.toTransporter();
    await this.chooseTransporterType('Commercial');
    await this.animalsPages.commercialTransporter.heading.waitFor(pageLoadWait);
  }

  async toPrivateTransporter(): Promise<void> {
    await this.toTransporter();
    await this.chooseTransporterType('Private');
    await this.animalsPages.privateTransporter.heading.waitFor(pageLoadWait);
  }

  /** Fills and saves the open private transporter add form, landing back on the
   * transporter list with the saved transporter first and already chosen. */
  async fillAndSavePrivateTransporterAddForm(details: PrivateTransporterDetails): Promise<void> {
    await this.animalsPages.privateTransporter.fill(details);
    await this.animalsPages.privateTransporter.saveAndContinue.click();
    await this.animalsPages.transporter.heading.waitFor(pageLoadWait);
  }

  async fillAndSaveCommercialTransporterAddFormToOverview(details: CommercialTransporterDetails): Promise<void> {
    await this.animalsPages.commercialTransporter.fill(details);
    await this.saveTransporterDetailsToOverview(this.animalsPages.commercialTransporter);
  }

  async toContactAddress(): Promise<void> {
    await this.startNotification();
    await this.answerCommodity();
    await this.animalsPages.overview.task('Contact address for this consignment').click();
    await this.animalsPages.contactAddress.heading.waitFor(pageLoadWait);
  }

  partyPicker(role: PartyRole): AnimalsPartyPickerPage {
    return this.animalsPages[PARTY_PICKER_KEYS[role]];
  }

  async toPartyPicker(role: PartyRole): Promise<void> {
    await this.startNotification();
    await this.answerCommodity();
    await this.animalsPages.overview.task('Roles and addresses').click();
    await this.animalsPages.addresses.addParty(role).click();
    await this.partyPicker(role).heading.waitFor(pageLoadWait);
  }

  async openInsAddAddressFromPicker(addressBookAdd: InsAddressBookAddPage, role: PartyRole): Promise<void> {
    await this.partyPicker(role).addNewAddress.click();
    await addressBookAdd.completeSignInIfRequested();
    await addressBookAdd.heading.waitFor(pageLoadWait);
  }

  async toInsAddAddressFromPicker(addressBookAdd: InsAddressBookAddPage, role: PartyRole): Promise<void> {
    await this.toPartyPicker(role);
    await this.openInsAddAddressFromPicker(addressBookAdd, role);
  }

  async toReview(answers: NotificationAnswers = MANDATORY_ANSWERS): Promise<void> {
    if (!this.context.referenceNumber) await this.startNotification();
    await this.completeAnswerSections(answers);
    await this.openReviewFromOverview();
  }

  async toDeclaration(answers: NotificationAnswers = MANDATORY_ANSWERS): Promise<void> {
    await this.startNotification();
    await this.completeAnswerSections(answers);
    await this.fromOverviewToDeclaration();
  }

  async submitNotification(answers: NotificationAnswers = MANDATORY_ANSWERS): Promise<void> {
    await this.toDeclaration(answers);
    await this.confirmDeclaration();
  }

  async walkToImportReason(
    originOptions: OriginOptions = {},
    species: CommodityLine[] = [MANDATORY_ANSWERS.commodityLines[0].species],
  ): Promise<string> {
    const referenceNumber = await this.createNotificationAtOrigin();

    await this.answerOriginAndSelectSpecies(species, originOptions);

    await this.animalsPages.importReason.heading.waitFor(pageLoadWait);
    return referenceNumber;
  }

  async walkToRolesAndAddressesWithoutCph(): Promise<string> {
    const pages = this.animalsPages;
    const referenceNumber = await this.walkToImportReason();

    await pages.importReason.saveAndContinue.click();

    await pages.consignmentDetails.heading.waitFor(pageLoadWait);
    await pages.consignmentDetails.numberOfAnimals.fill('1');
    await pages.consignmentDetails.saveAndContinue.click();

    await pages.animalIdentification.heading.waitFor(pageLoadWait);
    await pages.animalIdentification.saveAndContinue.click();

    await pages.additionalDetails.heading.waitFor(pageLoadWait);
    await pages.additionalDetails.saveAndContinue.click();

    await pages.arrivalDetails.heading.waitFor(pageLoadWait);
    await pages.arrivalDetails.chooseMeansOfTransport(meansOfTransport.airplane.display);
    await pages.arrivalDetails.saveAndContinue.click();

    await pages.transporter.heading.waitFor(pageLoadWait);
    await pages.transporter.transporter(MANDATORY_ANSWERS.transporter.display).check();
    await pages.transporter.saveAndContinue.click();

    await pages.accompanyingDocuments.heading.waitFor(pageLoadWait);
    await pages.accompanyingDocuments.continueButton.click();

    await pages.addresses.heading.waitFor(pageLoadWait);
    return referenceNumber;
  }

  private async walkFromTransporterToReview(
    transporter: string,
    document: AccompanyingDocumentAnswer,
    { addCph }: { addCph: boolean },
  ): Promise<void> {
    const pages = this.animalsPages;

    await pages.transporter.heading.waitFor(pageLoadWait);
    await pages.transporter.transporter(transporter).check();
    await pages.transporter.saveAndContinue.click();

    await pages.accompanyingDocuments.heading.waitFor(pageLoadWait);
    await this.uploadDocumentAndWaitForScan(document);
    await pages.accompanyingDocuments.continueButton.click();

    await pages.addresses.heading.waitFor(pageLoadWait);
    await this.addFiveParties();
    if (addCph) {
      await this.addCphAndLeaveAddresses();
    } else {
      await pages.addresses.continueButton.click();
    }

    await pages.contactAddress.heading.waitFor(pageLoadWait);
    await this.chooseContactAddress();

    await pages.notificationView.heading.waitFor(pageLoadWait);
  }

  async walkCattleByAir(document: AccompanyingDocumentAnswer): Promise<string> {
    const pages = this.animalsPages;
    const referenceNumber = await this.walkToImportReason({
      requiresRegionCode: 'Yes',
      internalReference: 'CATTLE-2026-01',
    });

    await pages.importReason.reason(importReasons.internalMarket.display).check();
    await pages.importReason.purpose(internalMarketPurposes.breeding.display).check();
    await pages.importReason.saveAndContinue.click();

    await pages.consignmentDetails.heading.waitFor(pageLoadWait);
    await pages.consignmentDetails.numberOfAnimals.fill('2');
    await pages.consignmentDetails.numberOfPackages.fill('1');
    await pages.consignmentDetails.saveAndContinue.click();

    await pages.animalIdentification.heading.waitFor(pageLoadWait);
    await pages.animalIdentification.earTag.fill('UK000000000001');
    await pages.animalIdentification.passportNumber.fill('PASSPORT-0001');
    await pages.animalIdentification.saveAndAddAnother.click();
    await pages.animalIdentification.savedAnimalRow(MANDATORY_ANSWERS.commodityLines[0].species, 1).waitFor(pageLoadWait);
    await pages.animalIdentification.earTag.fill('UK000000000002');
    await pages.animalIdentification.passportNumber.fill('PASSPORT-0002');
    await pages.animalIdentification.saveAndFinish.click();
    await pages.animalIdentification.savedAnimalRow(MANDATORY_ANSWERS.commodityLines[0].species, 2).waitFor(pageLoadWait);
    await pages.animalIdentification.saveAndContinue.click();

    await pages.additionalDetails.heading.waitFor(pageLoadWait);
    await pages.additionalDetails.certifiedFor(certificationPurposes.furtherKeeping.display).check();
    await pages.additionalDetails.containsUnweanedAnimals(yesNoValues.no).check();
    await pages.additionalDetails.saveAndContinue.click();

    await pages.arrivalDetails.heading.waitFor(pageLoadWait);
    await this.fillArrivalDetails({
      port: pointOfEntries.heathrowAirport.display,
      means: meansOfTransport.airplane.display,
      transportId: 'BA0117',
      documentReference: 'AWB-2026-0001',
    });
    await pages.arrivalDetails.saveAndContinue.click();

    await this.walkFromTransporterToReview(MANDATORY_ANSWERS.transporter.display, document, { addCph: true });
    return referenceNumber;
  }

  async walkHorseBySea(document: AccompanyingDocumentAnswer): Promise<string> {
    const pages = this.animalsPages;
    const referenceNumber = await this.walkToImportReason({ countryCode: countryCodes.eu.ireland }, [commodityLines.horse]);

    await pages.importReason.reason(importReasons.temporaryAdmissionHorses.display).check();
    await pages.importReason.temporaryAdmissionExitDate.fill(TEMPORARY_ADMISSION_EXIT_DATE);
    await pages.importReason.selectTemporaryAdmissionPortOfExit('GB HLY');
    await pages.importReason.saveAndContinue.click();

    await pages.consignmentDetails.heading.waitFor(pageLoadWait);
    await pages.consignmentDetails.numberOfAnimals.fill('1');
    await pages.consignmentDetails.numberOfPackages.fill('1');
    await pages.consignmentDetails.saveAndContinue.click();

    await pages.animalIdentification.heading.waitFor(pageLoadWait);
    await pages.animalIdentification.microchip.fill('900123456789012');
    await pages.animalIdentification.passportNumber.fill('IE-EQ-2026-0001');
    await pages.animalIdentification.horseName.fill('Dublin Bay');
    await pages.animalIdentification.saveAndContinue.click();

    await pages.additionalDetails.heading.waitFor(pageLoadWait);
    await pages.additionalDetails.certifiedFor(certificationPurposes.registeredEquineAnimal.display).check();
    await pages.additionalDetails.containsUnweanedAnimals(yesNoValues.no).check();
    await pages.additionalDetails.saveAndContinue.click();

    await pages.arrivalDetails.heading.waitFor(pageLoadWait);
    await this.fillArrivalDetails({
      port: pointOfEntries.holyheadPort.display,
      means: meansOfTransport.vessel.display,
      transportId: HORSE_TRANSPORT_ID,
      documentReference: 'BOL-2026-0001',
    });
    await pages.arrivalDetails.saveAndContinue.click();

    await this.walkFromTransporterToReview(HORSE_TRANSPORTER, document, { addCph: false });
    return referenceNumber;
  }

  async walkPoultryByRail(document: AccompanyingDocumentAnswer): Promise<string> {
    const pages = this.animalsPages;
    const referenceNumber = await this.walkToImportReason({ countryCode: countryCodes.eu.germany }, [commodityLines.chicken]);

    await pages.importReason.reason(importReasons.transit.display).check();
    await pages.importReason.selectTransitPortOfExit('GB HLY');
    await pages.importReason.selectTransitDestinationCountry(countryCodes.eu.ireland.value);
    await pages.importReason.saveAndContinue.click();

    await pages.consignmentDetails.heading.waitFor(pageLoadWait);
    await pages.consignmentDetails.numberOfAnimals.fill('400');
    await pages.consignmentDetails.saveAndContinue.click();

    await pages.additionalDetails.heading.waitFor(pageLoadWait);
    await pages.additionalDetails.certifiedFor(certificationPurposes.slaughter.display).check();
    await pages.additionalDetails.saveAndContinue.click();

    await pages.arrivalDetails.heading.waitFor(pageLoadWait);
    await this.fillArrivalDetails({
      port: pointOfEntries.doverPort.display,
      means: meansOfTransport.railway.display,
      transportId: 'WAGON-2026-0001',
      documentReference: 'CIM-2026-0001',
    });
    await pages.arrivalDetails.saveAndContinue.click();

    await pages.transitedCountries.heading.waitFor(pageLoadWait);
    await pages.transitedCountries.addCountry(countryCodes.eu.belgium.display);
    await pages.transitedCountries.addCountry(countryCodes.eu.france.display);
    await pages.transitedCountries.saveAndContinue.click();

    await this.walkFromTransporterToReview(MANDATORY_ANSWERS.transporter.display, document, { addCph: true });
    return referenceNumber;
  }

  async toDeclarationOfCurrentNotification(): Promise<void> {
    await this.animalsPages.notificationView.open(this.currentReferenceNumber());
    await this.animalsPages.notificationView.heading.waitFor(pageLoadWait);
    await this.continueFromReviewToDeclaration();
  }

  async submitFromReview(): Promise<void> {
    await this.continueFromReviewToDeclaration();
    await this.confirmDeclaration();
  }

  private async fromOverviewToDeclaration(): Promise<void> {
    await this.openReviewFromOverview();
    await this.continueFromReviewToDeclaration();
  }

  private async continueFromReviewToDeclaration(): Promise<void> {
    await this.animalsPages.notificationView.continueButton.click();
    await this.animalsPages.declaration.heading.waitFor(pageLoadWait);
  }

  private async confirmDeclaration(): Promise<void> {
    await this.animalsPages.declaration.confirmation.check();
    await this.animalsPages.declaration.continueButton.click();
    await this.animalsPages.confirmation.heading.waitFor(pageLoadWait);
  }
}
